# -*- coding: utf-8 -*-
"""
Created on Tue May 15 08:22:50 2018
@author: jkrom
"""

import pandas as pd
import re
import time
import requests
from bs4 import BeautifulSoup
from pathlib import Path
"""
start = time.time()
print('Collectiong input data')
col_names = ['currentPos', 'lastPos', 'weekPeakPos', 'totalPeakWeeks', 'title', 'artist', 'entrydate', 'entryPos',
             'peakPos', 'overallWeeks', 'dateCode','id']
hitlist = pd.read_csv('hitlist_updated_distinct.csv', sep=';',skiprows=1, names=col_names)
substitutions = {'featuring':'',':-)':'','featurning-':'', ' x ':'','\+-':'',
    '\!':'', 'N*E*R*D':' NERD ', 'feat-':'', 'LANDON CURE':'Landon-Cube',
    'with-':'',',':'','&':'and'}
"""
def replace(string, substitutions):

    substrings = sorted(substitutions, key=len, reverse=True)
    regex = re.compile('|'.join(map(re.escape, substrings)))
    return regex.sub(lambda match: substitutions[match.group(0)], string)

# Print iterations progress
#https://stackoverflow.com/questions/3173320/text-progress-bar-in-the-console
def printProgressBar (iteration, total):
    """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
    """
    prefix = 'Progress:'
    suffix = 'Complete - Item: '
    decimals = 5
    length = 50
    fill = '█'
    
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s %s of %s' % (prefix, bar, percent, suffix, iteration, total), end = '\r')
    # Print New Line on Complete
    if iteration == total: 
        print()


def lyrics_request(histlist, resume):
    
    col_names = ['currentPos', 'lastPos', 'weekPeakPos', 'totalPeakWeeks', 'title', 'artist', 'entrydate', 'entryPos',
             'peakPos', 'overallWeeks', 'dateCode','id']
    
    if resume == 0:
        print('starting from scratch')
        hitlist = pd.read_csv(histlist, sep=';',skiprows=1, names=col_names)
    else:
        print('resume at: ', resume)
        hitlist = pd.read_csv(histlist, sep=';',skiprows=resume + 1, names=col_names)
    
    
    song_titles = hitlist.title.tolist()
    artists = hitlist.artist.tolist()
    ids = hitlist.id.tolist()
    
    substitutions = {'featuring':'',':-)':'','featurning-':'', ' x ':'','\+-':'',
    '\!':'', 'N*E*R*D':' NERD ', 'feat-':'', 'LANDON CURE':'Landon-Cube',
    'with-':'',',':'','&':'and', 'AND HIS ORCHESTRA':' ', 'HIS ORCHESTRA':'', '/':' '}

    song_titles = [x for x in song_titles if str(x) !='nan']
    artists = [x for x in artists if str(x) !='nan']

    lyrics = []
    print_id = []
    print_artist = []
    print_songtitle = []
    
    error_song = []
    error_artist = []
    error_url = []

    try:
        
        l = len(ids)
        printProgressBar(0, l)
        for idx, songtitle in enumerate(song_titles):
           
            printProgressBar(idx + resume + 1, l)
          
            #advanced regex patterns
            songtitle = re.sub(r"\(","",songtitle)
            songtitle = re.sub(r"\)","",songtitle)
            songtitle = re.sub(r"\[.*\]","",songtitle)
            
 #          songtitle = re.sub(r'\W+', '-', songtitle)
            songtitle = re.sub(r"'", "", songtitle)
            songtitle = re.sub(r"!","",songtitle)
            songtitle = re.sub(r"\+","",songtitle)
            songtitle = re.sub(r" +","-",songtitle)
            songtitle = re.sub('[^A-Za-z0-9]+', '-', songtitle)
            artist= re.sub(r"\(.*\)","",artists[idx])
            artist= re.sub(r"\[.*\]"," ",artist)
           # artist = re.sub('[^A-Za-z0-9]+', '', artist)
            artist = re.sub(r'featuring[^()]+',"",artist)
            artist = re.sub(r'feat[^()]+',"",artist)
            artist = re.sub(r'with[^()]+',"",artist)
     #      artist = re.sub(r'\&[^()]+','',artist)
    #        artist = re.sub(r'\W+', '-', artist)
            artist = re.sub(r"'", "", artist)
            artist = re.sub(r"\+","",artist)
            artist = re.sub(r" +","-",artist)
            artist = re.sub(r"---","-",artist)
           # artist = re.sub('[^A-Za-z0-9]+', '-', artist)
    
            url = 'https://genius.com/'+replace(artist,substitutions)+replace(songtitle,substitutions)+'lyrics'
            page = requests.get(url)
            html = BeautifulSoup(page.text, 'html.parser')

            try:
               lyric_item = html.find('div', class_='lyrics').get_text()
               lyrics.append(lyric_item)
               print_id.append(ids[idx])
               print_artist.append(artist)
               print_songtitle.append(songtitle)
              
    
            except AttributeError:
                print_id.append(ids[idx])
                print_artist.append(artist)
                print_songtitle.append(songtitle)
                
                error_song.append(songtitle)
                error_artist.append(artist)
                error_url.append(url)
                lyrics.append('NaN')
                

        
    except KeyboardInterrupt:
        print('Interrupt from Keyboard')
    except IOError:
        print('Connection Error')  
    finally:  
        #write collected data to file
        data = {'id':print_id, 'artists':print_artist, 'song_titles':print_songtitle, 'lyrics':lyrics}
        lyricsdf = pd.DataFrame.from_dict(data, orient='columns')
        out_file = 'data/lyrics/lyrics.csv'
        lyricsdf.to_csv(out_file, sep=';', index = False, header = False, mode='a')
    
        error_data = {'song_title':error_song, 'artist':error_artist, 'url':error_url}
        errordf = pd.DataFrame.from_dict(error_data, orient='columns')
        error_file = 'data/lyrics/lyric_errors.csv'
        errordf.to_csv(error_file, sep=";", index = False, header = False, mode='a')
        
        #Store crash index and tids in temporary files
        idx = idx + resume
        df = pd.DataFrame({'crash_point':idx}, index=[0])
        df.to_csv('data/lyrics/crash_dump/index.csv', sep = ';', encoding = 'utf-8')
        
       # print('Script endet after: ' + time.time() - start)
        


if __name__ == '__main__':
    start = time.time()

    in_file = 'data/hitlist_updated_distinct_v3.csv'
    resume = Path('data/lyrics/crash_dump/index.csv')

    if resume.exists():
        print("Continue from previous Data set")
        col = ['idx']
        res = pd.read_csv(resume, sep=';', encoding='utf-8',skiprows=1, names = col)
        idx_res = res['idx'][0]
        print(idx_res)
        lyrics_request(in_file, idx_res)
    else:
        lyrics_request(in_file, 0)