# Python Scripts

<h2>API-Skript:</h2>

This script consumes a given Hitlist.csv (created by the umdm-downloader) and requests all songs contained from the Spotify API.

__Important!__

If you want to execute the script from the beginning, delete both index.csv and tids.csv from the temp folder. 
Otherwise the script will continue where it was suspended last time. From the project root folder please delete the track_info.csv, hitlist_updated.csv as well as the audio_features.csv, because the script will rather append new contents to these files than overwrite existing data!

__if the script fails AFTER all track infos have been retrieved, DO NOT start the API Script again. Please use the feature_req script instead.__




__Run Script:__
```
Clone repository
python api_script.py
```
__Outputs are:__
- Hitlist_updated.csv (Hitlist.csv with appended Spotify-IDs)
- Track_info.csv (Contains Track meta data, such as: Artist, Album, popularity etc.)
- Audio_Features.csv (Contains Audio Feature Objects for each song)
	
__TODO:__
- [ x ] Find cause and fix random crashes
- [ ] Make script executable with console parameters -> csv path

<h2>Feature Request Skript:</h2>

Request audio features after all track infos have been requested. This script is a backup solution if the api script fails while requesting audio features.

__Run Script:__
```
Clone repository
python feature_req.py
```
__Requirements:__
Outputs inside the temp folder. All track info requests have to be completed.
  
<h2>Lyrics-Crawler:</h2>
Consumes a given Hitlist_updated.csv and crawls genius.com for lyrics of the contained songs. 

__Run Script:__
```
Clone repository
python api_script.py
```
__Outputs are:__
- lyrics.csv (artist, title, lyrics, spotify-id)
- error_lyrics.csv (artist, title, request url for songs which could not be found by the crawler)
	
__TODO:__
- [ ] Improve Regex patterns
- [ ] Improve performance
- [ ] Make script executable with console parameters -> csv path

