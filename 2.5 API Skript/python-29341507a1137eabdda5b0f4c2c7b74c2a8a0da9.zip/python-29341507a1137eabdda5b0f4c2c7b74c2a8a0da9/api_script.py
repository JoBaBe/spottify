# -*- coding: utf-8 -*-

import pandas as pd
import spotipy
import time
import sys
from pandas.io.json import json_normalize
from spotipy.oauth2 import SpotifyClientCredentials
from pathlib import Path
import re


# Spotify authentication 
def auth():
    client_credentials_manager = SpotifyClientCredentials(client_id='1ca7923ecd024e85978168678102f22b',
                                                      client_secret='681d960e1cab41ed8b4f9c5d3937d8d1')

    sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)
    return sp


def replace(string, substitutions):
    
    substrings = sorted(substitutions, key=len, reverse=True)
    regex = re.compile('|'.join(map(re.escape, substrings)))
    return regex.sub(lambda match: substitutions[match.group(0)], string)

def request_songs(in_f, out_f,out_hitlist, size, sp, c_res, idx_res):
    
    if not c_res == 0:
            res_point = (c_res*chunksize)+idx_res
            print (res_point)
    elif (c_res == 0) and (idx_res != 0):
            res_point = idx_res
            print (res_point)
    else:
        res_point = 0;
       
    if not res_point == 0:
        print('resume at: ', res_point)
        hitlist = pd.read_csv(in_f, sep=';', chunksize=size, header=None, skiprows=res_point)
    else:
        print('starting from scratch')
        hitlist = pd.read_csv(in_f, sep=';', chunksize=size, header=None)
        
    itemdf = pd.DataFrame([])
    tids = []
    
    try: 
        for c, chunk in enumerate(hitlist):
   
          #  chunk.columns = ['currentPos', 'lastPos', 'weekPeakPos', 'totalPeakWeeks', 'title', 'artist', 'entrydate', 'entryPos', 'peakPos', 'overallWeeks', 'dateCode']
            print(chunk)
            song_titles = chunk.iloc[:,4].tolist()
            artists_hitlist = chunk.iloc[:,5].tolist()  
          #  song_titles = chunk['title'].tolist()
          #  artists_hitlist = chunk['artist'].tolist()  
        
            for idx,song_title in enumerate(song_titles):
                print(time.time() - start)
                print('Chunk: ',c_res + c,' Item: ',idx_res + idx)
                print(song_title)
                
            
                track_info = sp.search(q=song_title+replace(artists_hitlist[idx],substitutions).split(' or ')[0], limit=1)
            
                if len(track_info['tracks']['items']) is 0:
                    items = json_normalize(track_info)
                    tids.append('NaN')
                else:
                    items = json_normalize(track_info['tracks']['items'][0], 'artists', meta=['popularity', 'id', 'duration_ms', 'explicit', 'name'], record_prefix='artist')
                    tids.append(track_info['tracks']['items'][0]['id'])
        
                itemdf = itemdf.append(items)
    except KeyboardInterrupt:
        print('Interrupt from Keyboard')
    except IOError:
        print('Connection Error')  
    finally:  
        #write collected data to file
        itemdf.to_csv(out_f,sep=';', encoding='utf-8', index = False, header = False, mode='a')
        
        #Store crash index and tids in temporary files
        c = c + c_res
        idx = idx + idx_res 
        df = pd.DataFrame({'c':c,'idx':idx},index=[0])
        df.to_csv('data/temp/index.csv', sep = ';', encoding = 'utf-8')
        
        df2 = pd.DataFrame({'tids':tids})
        df2.to_csv('data/temp/tids.csv', sep = ';', encoding = 'utf-8', index = False, header = False, mode='a')
    
    return tids
        
        
def chunks(l, n):
    for i in range(0, len(l), n):
        yield l[i:i + n]


# search for audio features
def feature_request(tids, sp):
    tid_ = list(chunks(tids, 50))
    features = []
    for tid in tid_:
        feature = sp.audio_features(tid)
        features.extend(feature)
    return features


def write_files(in_f, out_hitlist, out_features, tids, features):
    col_names = ['currentPos', 'lastPos', 'weekPeakPos', 'totalPeakWeeks', 'title', 'artist', 'entrydate', 'entryPos',
             'peakPos', 'overallWeeks', 'dateCode']
    hitlist = pd.read_csv(in_f, sep=';', names=col_names)
    hitlist['id'] = tids
    hitlist.to_csv(out_hitlist, sep=';', encoding='utf-8')
    
    df = pd.DataFrame(list(filter(None,features)))
    df.to_csv(out_features, sep=';', encoding='utf-8')
    
if __name__ == '__main__':
    start = time.time()
    #TODO: Change to console argument
    #file input
    in_file='data/us_billboard_v2_utf8.csv'
    chunksize = 10000
    
    resume = Path('data/temp/index.csv')
#'66LIL''66 LIL','' ' ', 'HIS ORCHESTRA' ''}
    # create csv files
    out_songs = 'data/track_info.csv'
    out_features = 'data/audio_features.csv'
    out_hitlist = 'data/hitlist_updated.csv'
    substitutions = {'featuring':' ', '&':' ',':-)':' ','featurning':' ', ' x ':' ', 'N*E*R*D':' NERD ', 'feat':' ', 'LANDON CURE':' Landon Cube ', ',':' ','AND HIS ORCHESTRA':' ', 'HIS ORCHESTRA':'', '/':' ' }
    
    sp = auth()

    if resume.exists():
        print("Continue from previous Data set")
        col = ['','c','idx']
        res = pd.read_csv(resume, sep=';', encoding='utf-8',skiprows=1, names = col)
        c_res = res['c'][0]
        idx_res = res['idx'][0]
        print(c_res,idx_res)
        
        request_songs(in_file, out_songs,out_hitlist, chunksize, sp, c_res, idx_res)
        cols = ['tids']
        tidsdf = pd.read_csv('data/temp/tids.csv', sep=';', names = cols)
        tids = tidsdf['tids'].tolist()
        features = feature_request(tids, sp)
    
        write_files(in_file, out_hitlist, out_features, tids, features)
       
        
        


    else:    
        tids = request_songs(in_file, out_songs,out_hitlist, chunksize, sp, 0, 0)
        features = feature_request(tids, sp)
    
        write_files(in_file, out_hitlist, out_features, tids, features)


    delta = time.time() - start
    print("data retrieved and processed in %.2f seconds" % (delta,))
    

