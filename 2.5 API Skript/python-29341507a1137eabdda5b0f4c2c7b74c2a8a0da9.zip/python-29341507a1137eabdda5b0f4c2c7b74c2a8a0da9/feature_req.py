# -*- coding: utf-8 -*-
"""
Created on Wed May 30 14:37:38 2018

@author: jkrom
"""

import pandas as pd
import spotipy
import time
import sys
from pandas.io.json import json_normalize
from spotipy.oauth2 import SpotifyClientCredentials
from pathlib import Path
import re

# Spotify authentication 
def auth():
    client_credentials_manager = SpotifyClientCredentials(client_id='1ca7923ecd024e85978168678102f22b',
                                                      client_secret='681d960e1cab41ed8b4f9c5d3937d8d1')

    sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)
    return sp


def chunks(l, n):
    for i in range(0, len(l), n):
        yield l[i:i + n]


# search for audio features
def feature_request(tids, sp):
    tid_ = list(chunks(tids, 50))
    features = []
    for idx, tid in enumerate(tid_):
        print(idx)
        feature = sp.audio_features(tid)
        features.extend(feature)
    return features


def write_files(in_f, out_hitlist, out_features, tids, features):
    col_names = ['currentPos', 'lastPos', 'weekPeakPos', 'totalPeakWeeks', 'title', 'artist', 'entrydate', 'entryPos',
             'peakPos', 'overallWeeks', 'dateCode']
    hitlist = pd.read_csv(in_f, sep=';', names=col_names)
    hitlist['id'] = tids
    hitlist.to_csv(out_hitlist, sep=';', encoding='utf-8')
    
    df = pd.DataFrame(list(filter(None,features)))
    df.to_csv(out_features, sep=';', encoding='utf-8')
    
if __name__ == '__main__':
    start = time.time()

    # create csv files
    """ Path to hitlist.csv """    
    in_file='data/us_billboard_v2_utf8.csv'
    out_features = 'data/audio_features.csv'
    out_hitlist = 'data/hitlist_updated.csv'
 
    sp = auth()
    
    cols = ['tids']
    tidsdf = pd.read_csv('data/temp/tids_all.csv', sep=';', names = cols)

    tids_ = tidsdf[tidsdf['tids'].notnull()]
    tids = tids_['tids'].values.tolist()
    features = feature_request(tids, sp)
    
    write_files(in_file, out_hitlist, out_features, tids, features)
    delta = time.time() - start
    print("data retrieved and processed in %.2f seconds" % (delta,))
    

